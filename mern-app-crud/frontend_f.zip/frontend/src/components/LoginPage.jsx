// src/components/LoginPage.jsx
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { TextField, Button, Paper, Typography, Box, Grid } from '@mui/material';
import axios from 'axios';

const LoginPage = () => {
  const [form, setForm] = useState({ email: '', password: '' });
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState(''); // 'success' or 'error'
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5001/api/auth/login', {
        email: form.email.trim(),
        password: form.password.trim(),
      });

      const token = res.data.token;

      if (token) {
        localStorage.setItem('authToken', token);
        setMessage('Login successful!');
        setMessageType('success');
        navigate('/users');
      } else {
        setMessage('Invalid credentials!');
        setMessageType('error');
      }
    } catch (err) {
      setMessage('Incorrect email or password. Please try again.');
      setMessageType('error');
    }
  };

  return (
    <Grid container justifyContent="center">
      <Grid item xs={12} md={4}>
        <Paper sx={{ p: 4, mt: 8 }}>
          <Typography variant="h5" gutterBottom>
            Login
          </Typography>
          <Box component="form" onSubmit={handleSubmit}>
            <TextField
              label="Email"
              name="email"
              value={form.email}
              onChange={handleChange}
              fullWidth
              required
              sx={{ mb: 2 }}
            />
            <TextField
              label="Password"
              name="password"
              value={form.password}
              onChange={handleChange}
              fullWidth
              required
              type="password"
              sx={{ mb: 2 }}
            />
            <Button type="submit" variant="contained" fullWidth>
              Login
            </Button>

            {message && (
              <Typography
                sx={{
                  mt: 2,
                  color: messageType === 'success' ? 'green' : 'red',
                  fontWeight: 500,
                }}
              >
                {message}
              </Typography>
            )}

            <Typography align="center" sx={{ mt: 2 }}>
              Don&apos;t have an account?{' '}
              <Link to="/register" style={{ textDecoration: 'none', color: '#1976d2', fontWeight: 500 }}>
                Register
              </Link>
            </Typography>
          </Box>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default LoginPage;